# `util` for Sketch

All the [util nodejs fs](https://nodejs.org/api/util.html) API is available.

Additionally, 2 more methods are available:
- `toArray`
- `toObject`
which cast assimilated arrays (`NSArray`) and objects (`NSDictionary`) to a proper JS array and object respectively.
